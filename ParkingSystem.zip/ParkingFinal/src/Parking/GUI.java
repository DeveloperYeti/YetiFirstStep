package Parking;

import java.awt.Button;
import java.awt.EventQueue;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;


import javax.swing.JTextPane;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.Color;
import javax.swing.border.LineBorder;

public class GUI extends JFrame {

   private DatabaseConnection dbconn;

   private int max_length;
   private String car_num;
   private int vehicle_type;

   private static final long serialVersionUID = 1L;
   private JPanel contentPane;
   private JTextField textField;

   /**
    * Launch the application.
    */
   public static void main(String[] args) {
      EventQueue.invokeLater(new Runnable() {
         public void run() {
            try {
               GUI frame = new GUI();
               frame.setVisible(true);
            } catch (Exception e) {
               e.printStackTrace();
            }
         }
      });
   }

   /**
    * Create the frame.
    */

   public GUI() {
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setBounds(50, 50, 526, 357);
      contentPane = new JPanel();
      contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

      setContentPane(contentPane);
      contentPane.setLayout(null);

      dbconn = new DatabaseConnection();
      dbconn.startConnection();

      JFrame JFrame = new JFrame();

      JButton button_insert_1 = new JButton("1");
      button_insert_1.setBorder(new LineBorder(new Color(0, 0, 0)));
      button_insert_1.setBackground(new Color(255, 255, 255));
      button_insert_1.setForeground(new Color(0, 0, 0));
      button_insert_1.addMouseListener(new MouseAdapter() {
         @Override
         public void mouseClicked(MouseEvent e) {
            length_check(textField.getText());
            if (max_length == 0)
               textField.setText(textField.getText() + "1");
//            차량번호 추가
         }
      });
      button_insert_1.setBounds(91, 66, 97, 46);
      contentPane.add(button_insert_1);

      JButton button_insert_2 = new JButton("2");
      button_insert_2.setBorder(new LineBorder(new Color(0, 0, 0)));
      button_insert_2.setBackground(new Color(255, 255, 255));
      button_insert_2.setForeground(new Color(0, 0, 0));
      button_insert_2.addMouseListener(new MouseAdapter() { 
         @Override
         public void mouseClicked(MouseEvent e) {
            length_check(textField.getText());
            if (max_length == 0)
               textField.setText(textField.getText() + "2");
         }
      });
      button_insert_2.setBounds(200, 66, 97, 46);
      contentPane.add(button_insert_2);

      JButton button_insert_3 = new JButton("3");
      button_insert_3.setBorder(new LineBorder(new Color(0, 0, 0)));
      button_insert_3.setBackground(new Color(255, 255, 255));
      button_insert_3.setForeground(new Color(0, 0, 0));
      button_insert_3.addMouseListener(new MouseAdapter() {
         @Override
         public void mouseClicked(MouseEvent e) {
            length_check(textField.getText());
            if (max_length == 0)
               textField.setText(textField.getText() + "3");
         }
      });
      button_insert_3.setBounds(309, 66, 97, 46);
      contentPane.add(button_insert_3);

      JButton button_insert_4 = new JButton("4");
      button_insert_4.setBorder(new LineBorder(new Color(0, 0, 0)));
      button_insert_4.setBackground(new Color(255, 255, 255));
      button_insert_4.setForeground(new Color(0, 0, 0));
      button_insert_4.addMouseListener(new MouseAdapter() {
         @Override
         public void mouseClicked(MouseEvent e) {
            length_check(textField.getText());
            if (max_length == 0)
               textField.setText(textField.getText() + "4");
         }
      });
      button_insert_4.setBounds(91, 122, 97, 46);
      contentPane.add(button_insert_4);

      JButton button_insert_5 = new JButton("5");
      button_insert_5.setBorder(new LineBorder(new Color(0, 0, 0)));
      button_insert_5.setBackground(new Color(255, 255, 255));
      button_insert_5.setForeground(new Color(0, 0, 0));
      button_insert_5.addMouseListener(new MouseAdapter() {
         @Override
         public void mouseClicked(MouseEvent e) {
            length_check(textField.getText());
            if (max_length == 0)
               textField.setText(textField.getText() + "5");
         }
      });
      button_insert_5.setBounds(200, 122, 97, 46);
      contentPane.add(button_insert_5);

      JButton button_insert_6 = new JButton("6");
      button_insert_6.setBorder(new LineBorder(new Color(0, 0, 0)));
      button_insert_6.setBackground(new Color(255, 255, 255));
      button_insert_6.setForeground(new Color(0, 0, 0));
      button_insert_6.addMouseListener(new MouseAdapter() {
         @Override
         public void mouseClicked(MouseEvent e) {
            length_check(textField.getText());
            if (max_length == 0)
               textField.setText(textField.getText() + "6");
         }
      });
      button_insert_6.setBounds(309, 122, 97, 46);
      contentPane.add(button_insert_6);

      JButton button_insert_7 = new JButton("7");
      button_insert_7.setBorder(new LineBorder(new Color(0, 0, 0)));
      button_insert_7.setBackground(new Color(255, 255, 255));
      button_insert_7.setForeground(new Color(0, 0, 0));
      button_insert_7.addMouseListener(new MouseAdapter() {
         @Override
         public void mouseClicked(MouseEvent e) {
            length_check(textField.getText());
            if (max_length == 0)
               textField.setText(textField.getText() + "7");
         }
      });
      button_insert_7.setBounds(91, 178, 97, 46);
      contentPane.add(button_insert_7);

      JButton button_insert_8 = new JButton("8");
      button_insert_8.setBorder(new LineBorder(new Color(0, 0, 0)));
      button_insert_8.setBackground(new Color(255, 255, 255));
      button_insert_8.setForeground(new Color(0, 0, 0));
      button_insert_8.addMouseListener(new MouseAdapter() {
         @Override
         public void mouseClicked(MouseEvent e) {
            length_check(textField.getText());
            if (max_length == 0)
               textField.setText(textField.getText() + "8");
         }
      });

      button_insert_8.setBounds(200, 178, 97, 46);
      contentPane.add(button_insert_8);

      JButton button_insert_9 = new JButton("9");
      button_insert_9.setBorder(new LineBorder(new Color(0, 0, 0)));
      button_insert_9.setBackground(new Color(255, 255, 255));
      button_insert_9.setForeground(new Color(0, 0, 0));
      button_insert_9.addMouseListener(new MouseAdapter() {
         @Override
         public void mouseClicked(MouseEvent e) {
            length_check(textField.getText());
            if (max_length == 0)
               textField.setText(textField.getText() + "9");
         }
      });
      button_insert_9.setBounds(309, 178, 97, 46);
      contentPane.add(button_insert_9);

      JButton button_insert_0 = new JButton("0");
      button_insert_0.setBorder(new LineBorder(new Color(0, 0, 0)));
      button_insert_0.setBackground(new Color(255, 255, 255));
      button_insert_0.addMouseListener(new MouseAdapter() {
         @Override
         public void mouseClicked(MouseEvent e) {
            length_check(textField.getText());
            if (max_length == 0)
               textField.setText(textField.getText() + "0");
         }
      });
      button_insert_0.setBounds(200, 234, 97, 46);
      contentPane.add(button_insert_0);

      JButton button_subString = new JButton("<-");
      button_subString.setBorder(new LineBorder(new Color(0, 0, 0)));
      button_subString.setBackground(new Color(255, 255, 255));
      button_subString.addMouseListener(new MouseAdapter() {
         @Override

         public void mouseClicked(MouseEvent e) {
            if (!textField.getText().isEmpty()) {
                textField.setText(textField.getText().substring(0, textField.getText().length() - 1));
            }
         }
      });
      button_subString.setBounds(309, 234, 97, 46);
      contentPane.add(button_subString);

      JButton button_clear = new JButton("CLEAR");
      button_clear.setBorder(new LineBorder(new Color(0, 0, 0)));
      button_clear.setBackground(new Color(255, 255, 255));
      button_clear.addMouseListener(new MouseAdapter() {
         @Override
         public void mouseClicked(MouseEvent e) {
            textField.setText(null);
            length_check(textField.getText());
         }
      });
      button_clear.setBounds(91, 234, 97, 46);
      contentPane.add(button_clear);

      JRadioButton vehicle_type_1_radio = new JRadioButton("SEDAN");
      vehicle_type_1_radio.setBackground(new Color(240,240,240));
      vehicle_type_1_radio.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            vehicle_type = 0;
         }
      });
      vehicle_type_1_radio.setSelected(true);
      vehicle_type_1_radio.setHorizontalAlignment(SwingConstants.LEFT);
      vehicle_type_1_radio.setBounds(8, 66, 75, 23);
      contentPane.add(vehicle_type_1_radio);

      JRadioButton vehicle_type_2_radio = new JRadioButton("SUV");
      vehicle_type_2_radio.setBackground(new Color(240,240,240));
      vehicle_type_2_radio.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            vehicle_type = 1;
         }
      });
      vehicle_type_2_radio.setSelected(true);
      vehicle_type_2_radio.setHorizontalAlignment(SwingConstants.LEFT);
      vehicle_type_2_radio.setBounds(8, 100, 75, 23);
      contentPane.add(vehicle_type_2_radio);

//      라디오 버튼의 그룹화
      ButtonGroup group = new ButtonGroup();
      group.add(vehicle_type_1_radio);
      group.add(vehicle_type_2_radio);

      textField = new JTextField();
      textField.setBackground(new Color(192, 192, 192));
      textField.setHorizontalAlignment(SwingConstants.CENTER);
      textField.setText("차량번호 입력");
      textField.setFont(new Font("맑은 고딕", Font.BOLD, 20));
      textField.setEditable(false);
      textField.setBounds(91, 10, 315, 46);
      textField.setBorder(javax.swing.BorderFactory.createEmptyBorder());
      contentPane.add(textField);
      textField.setColumns(10);
      
      JButton Enter = new JButton("입고");
      Enter.addMouseListener(new MouseAdapter() {
          @Override
          public void mouseClicked(MouseEvent e) {
              if (textField.getText().length() == 4) { // Assuming car number length is 4
                  String carNum = textField.getText(); 
                  String vehicleType = vehicle_type_check();

                  if ("세단".equals(vehicleType)) {
                      vehicleType = "sedan"; // Convert to English for database consistency
                  } else if ("SUV".equals(vehicleType)) {
                      vehicleType = "suv";
                  }

                  dbconn.insertCar(vehicleType, carNum);
                  text_field_reset();
              }
          }
      });
      Enter.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
          }
      });
      Enter.setBounds(418, 66, 80, 102);
      contentPane.add(Enter);
      
      addWindowListener(new WindowAdapter() {
          @Override
          public void windowClosing(WindowEvent e) {
              dbconn.dropTable(); // 데이터베이스 테이블 삭제
              System.out.println("테이블 삭제되었습니다.");
              System.exit(0); // 프로그램 종료
          }
      });
      
      JButton Exit = new JButton("출고");
      Exit.addMouseListener(new MouseAdapter() {
          @Override
          public void mouseClicked(MouseEvent e) {
              if (textField.getText().length() == 4) { // Assuming car number length is 4
                  String carNum = textField.getText();
                  dbconn.deleteCar(carNum);
                  text_field_reset();
              }
          }
      });
      Exit.setBounds(418, 178, 80, 102);
      contentPane.add(Exit);
      
      JButton Status = new JButton("<html>주차<br>현황</html>");
      Status.addMouseListener(new MouseAdapter() {
      	@Override
      	public void mouseClicked(MouseEvent e) {
      		ParkingGUI ParkingGUI = new ParkingGUI();
      		 ParkingGUI.setVisible(true);
      	}
      });
      Status.addActionListener(new ActionListener() {
      	public void actionPerformed(ActionEvent e) {
      	}
      });
      Status.setBounds(12, 134, 71, 148);
      contentPane.add(Status);
   }

   public void length_check(String car_num) {
      if (car_num.length() == 4) {
         max_length = 1;
         
      } else {
         max_length = 0;
      }

      if (textField.getText().equals("차량번호 입력")) {
         textField.setText(null);
      } else if (textField.getText().isEmpty()) {
         textField.setText("차량번호 입력");
      }
   }

   public String vehicle_type_check() {
      String segment = null;
      switch (vehicle_type) {
      case 0: {
         segment = "세단";
         break;
      }
      case 1: {
         segment = "SUV";
         break;
      }
      }
      return segment;
   }
   
   public void text_field_reset() {
      textField.setText("차량번호 입력");
   }
   
   public void insert() {
      
   }

   public void vehicle_info_send(String car_num, int vehicle_type) {

   }
}