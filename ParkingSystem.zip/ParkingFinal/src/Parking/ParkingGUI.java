package Parking;

import java.util.List;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class ParkingGUI {
    private JFrame frame;
    private JTable parkingTable;
    private DefaultTableModel tableModel;
    private DatabaseConnection dbConnection;
    
    public ParkingGUI() {
        dbConnection = new DatabaseConnection();

        // 테이블 모델 설정
        tableModel = new DefaultTableModel(new Object[]{"1", "2", "3", "4", "5"}, 4); // 4행 5열 테이블
        parkingTable = new JTable(tableModel);

        frame = new JFrame("주차 관리 시스템");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(400, 200); // 프레임 크기 조정
        frame.add(new JScrollPane(parkingTable)); // 스크롤 가능한 테이블 추가
        frame.setVisible(true);

        updateParkingSpacesFromDatabase();
    }

    private void updateParkingSpacesFromDatabase() {
        List<Car> cars = dbConnection.selectCarsAndDisplayStatus();

        // 테이블 초기화
        for (int i = 0; i < parkingTable.getRowCount(); i++) {
            for (int j = 0; j < parkingTable.getColumnCount(); j++) {
                parkingTable.setValueAt("Empty", i, j);
            }
        }

        // 차량 정보로 테이블 업데이트
        for (Car car : cars) {
            String carType = car.getType().toLowerCase(); // carType을 소문자로 변환
            String carNumber = car.getNumber();
            String parkingSpace = car.getParkingSpace();
            int parkingNumber;
            int row = -1;
            int col = -1;
            try {
                parkingNumber = Integer.parseInt(parkingSpace.replaceAll("\\D+", ""));
            } catch (NumberFormatException e) {
                continue; // 숫자 변환에 실패하면 다음 차량으로 넘어감
            }

            
            if ("suv".equals(carType)) {
                if (parkingNumber >= 1 && parkingNumber <= 5) {
                    row = 0;
                    col = parkingNumber - 1;
                }
            } else if ("sedan".equals(carType)) {
                if (parkingNumber >= 1 && parkingNumber <= 15) {
                    row = (parkingNumber - 1) / 5 + 1; // 주차공간 번호에 맞게 행 계산
                    col = (parkingNumber - 1) % 5;
                }
            } else {
                continue; // 알 수 없는 차량 유형은 무시
            }

            parkingTable.setValueAt(carType.toUpperCase() + " " + carNumber, row, col);
        }
    }
    
    public void setVisible(boolean visible) {
        if (frame != null) {
            frame.setVisible(visible);
        }
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ParkingGUI());
    }
}