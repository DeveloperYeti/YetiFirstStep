package Parking;

public class Car {
    private String type;
    private String number;
    private String parkingSpace;

    public Car(String type, String number, String parkingSpace) {
        this.type = type;
        this.number = number;
        this.parkingSpace = parkingSpace;
    }

    public String getType() {
        return type;
    }

    public String getNumber() {
        return number;
    }

    public String getParkingSpace() {
        return parkingSpace;
    }
}