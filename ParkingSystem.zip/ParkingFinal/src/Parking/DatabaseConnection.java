package Parking;

import java.sql.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class DatabaseConnection {
	static Connection conn;
	String url = "jdbc:oracle:thin:@localhost:1521:xe";
	String userid = "c##ho";
	String pwd = "hoseok";

	public DatabaseConnection() {
		this.url = url;
		this.userid = userid;
		this.pwd = pwd;

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(url, userid, pwd);

			// Cars 테이블이 존재하는지 확인
			DatabaseMetaData metaData = conn.getMetaData();
			ResultSet tables = metaData.getTables(null, null, "CARS", null);
			if (!tables.next()) {
				// Cars 테이블이 존재하지 않으면 생성
				String createTableSql = "CREATE TABLE Cars (car_type VARCHAR(50), car_number VARCHAR(50), parking_location VARCHAR(20))";
				Statement stmt = conn.createStatement();
				stmt.executeUpdate(createTableSql);
				stmt.close();
			}
			tables.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void startConnection() {
	    try {
	        Class.forName("oracle.jdbc.driver.OracleDriver");
	        conn = DriverManager.getConnection(url, userid, pwd);

	        // Call checkAndCreateTable inside a try-catch block
	        try {
	            checkAndCreateTable();
	            System.out.println("테이블 생성");
	        } catch (SQLException e) {
	            System.out.println("테이블 생성 오류: " + e.getMessage());
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}
	
	private void checkAndCreateTable() throws SQLException {
	    DatabaseMetaData metaData = conn.getMetaData();
	    ResultSet tables = metaData.getTables(null, null, "CARS", null);
	    if (!tables.next()) {
	        String createTableSql = "CREATE TABLE Cars (car_type VARCHAR(50), car_number VARCHAR(50), parking_location VARCHAR(20))";
	        Statement stmt = conn.createStatement();
	        stmt.executeUpdate(createTableSql);
	        stmt.close();
	    }
	    tables.close();
	}

	
	// 차량 입고 부분
	public void insertCar(String carType, String carNumber) {
	    try {
	        // Check if the car number already exists in the database
	        if (checkCarNumberExists(carNumber)) {
	            System.out.println("Car number " + carNumber + " already exists.");
	            return;
	        }

	        // Generate a list of available parking spaces
	        List<String> availableSpaces = getAvailableSpaces(carType);

	        if (availableSpaces.isEmpty()) {
	            System.out.println("No available parking spaces");
	            return;
	        }

	        // Randomly select a parking space from the available spaces
	        Random random = new Random();
	        String parkingLocation = availableSpaces.get(random.nextInt(availableSpaces.size()));

	        // Insert the car record into the database
	        String sql = "INSERT INTO Cars (car_type, car_number, parking_location) VALUES (?, ?, ?)";
	        PreparedStatement pstmt = conn.prepareStatement(sql);
	        pstmt.setString(1, carType);
	        pstmt.setString(2, carNumber);
	        pstmt.setString(3, parkingLocation);
	        pstmt.executeUpdate();
	        pstmt.close();

	        System.out.println("Car parked in " + parkingLocation);
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
	
	private boolean checkCarNumberExists(String carNumber) throws SQLException {
	    String sql = "SELECT COUNT(*) FROM Cars WHERE car_number = ?";
	    PreparedStatement pstmt = conn.prepareStatement(sql);
	    pstmt.setString(1, carNumber);
	    ResultSet rs = pstmt.executeQuery();
	    boolean exists = rs.next() && rs.getInt(1) > 0;
	    rs.close();
	    pstmt.close();
	    return exists;
	}

	
	private List<String> getAvailableSpaces(String carType) throws SQLException {
        List<String> availableSpaces = new ArrayList<>();

        // Check the number of cars already parked
        int sedanCount = getCountOfCarType("sedan");
        int suvCount = getCountOfCarType("suv");

        if ("sedan".equalsIgnoreCase(carType)) {
            // Add available sedan spaces
            for (int i = 1; i <= 15; i++) {
                availableSpaces.add("SedanSpace-" + i);
            }

            // Add available SUV spaces if all sedan spaces are taken
            if (sedanCount >= 15) {
                for (int i = 1; i <= 5; i++) {
                    availableSpaces.add("SuvSpace-" + i);
                }
            }
        } else if ("suv".equalsIgnoreCase(carType)) {
            // Add available SUV spaces
            for (int i = 1; i <= 5; i++) {
                availableSpaces.add("SuvSpace-" + i);
            }
        }

        // Remove spaces that are already taken
        String sql = "SELECT parking_location FROM Cars";
        PreparedStatement pstmt = conn.prepareStatement(sql);
        ResultSet rs = pstmt.executeQuery();
        while (rs.next()) {
            availableSpaces.remove(rs.getString("parking_location"));
        }
        rs.close();
        pstmt.close();

        return availableSpaces;
    }
	
	
    private int getCountOfCarType(String carType) throws SQLException {
        String sql = "SELECT COUNT(*) FROM Cars WHERE car_type = ?";
        PreparedStatement pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, carType);
        ResultSet rs = pstmt.executeQuery();
        int count = 0;
        if (rs.next()) {
            count = rs.getInt(1);
        }
        rs.close();
        pstmt.close();
        return count;
    }

    
    
    // ParkingGUI 주차현황 연결 부분
    public List<Car> selectCarsAndDisplayStatus() {
        List<Car> cars = new ArrayList<>();
        try {
            String sql = "SELECT car_type, car_number, parking_location FROM Cars";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                String type = rs.getString("car_type");
                String number = rs.getString("car_number");
                String parkingSpace = rs.getString("parking_location");
                cars.add(new Car(type, number, parkingSpace));
            }

            rs.close();
            pstmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return cars;
    }
    
    
    
	
	// 테이블 드랍 및 삭제 부분
	
    
    public void deleteCar(String carNumber) {
        try {
            // Prepare a SQL statement to delete the car based on its number
            String sql = "DELETE FROM Cars WHERE car_number = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, carNumber);
            int rowsAffected = pstmt.executeUpdate();
            
            pstmt.close();

            if (rowsAffected > 0) {
                System.out.println("Car with number " + carNumber + " has been removed from the parking lot.");
            } else {
                System.out.println("No car found with number " + carNumber + ".");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
	public void dropTable() {
		try {
			Statement stmt = conn.createStatement();
			stmt.executeUpdate("DROP TABLE Cars");
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	
	public void closeConnection() {
		try {
			if (conn != null) {
				conn.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	

}