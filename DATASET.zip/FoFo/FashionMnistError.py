import tensorflow as tf
from tensorflow import keras
import numpy as np
import matplotlib.pyplot as plt

(train_images, train_labels), (test_images, test_labels) = keras.datasets.fashion_mnist.load_data()
train_images = train_images.reshape((60000, 28, 28, 1))
test_images = test_images.reshape((10000, 28, 28, 1))
train_images, test_images = train_images / 255.0, test_images / 255.0

fall_list = []
fall_arglist = []
fall_label = []
fall_image = []

x_train = train_images[:50000]
y_train = train_labels[:50000]
x_val = train_images[50000:]
y_val = train_labels[50000:]

model = keras.Sequential([
    keras.layers.Conv2D(32, (3, 3), activation='relu', input_shape=(28, 28, 1)),
    keras.layers.MaxPooling2D((2, 2)),
    keras.layers.Conv2D(64, (3, 3), activation='relu'),
    keras.layers.MaxPooling2D((2, 2)),
    keras.layers.Conv2D(64, (3, 3), activation='relu'),
    keras.layers.Flatten(),
    keras.layers.Dense(64, activation='relu'),
    keras.layers.Dense(10, activation='softmax')
])

model.summary()

model.compile(optimizer='adam',
              loss='sparse_categorical_crossentropy',
              metrics=['accuracy'])

model_history = model.fit(x_train, y_train, epochs=50, batch_size=512, shuffle=True, validation_data=(x_val, y_val), verbose=1)

plt.figure(figsize=(18, 6))

plt.subplot(1, 2, 1)
plt.plot(model_history.history['loss'], color="blue", label="Loss")
plt.plot(model_history.history['val_loss'], color="orange", label="Validation Loss")
plt.ylabel("Loss")
plt.xlabel("Number of Epochs")
plt.legend()

plt.subplot(1, 2, 2)
plt.plot(model_history.history['accuracy'], color="green", label="Accuracy")
plt.plot(model_history.history['val_accuracy'], color="red", label="Validation Accuracy")
plt.ylabel("Accuracy")
plt.xlabel("Number of Epochs")
plt.legend()

plt.tight_layout()
plt.legend(loc="best")
plt.show()

class_names = ['T-shirt/top', 'Trouser', 'Pullover', 'Dress', 'Coat',
               'Sandal', 'Shirt', 'Sneaker', 'Bag', 'Ankle boot']
predictions = model.predict(test_images)


def append_falllist(i, predictions_array, true_labels, img):
    true_label = true_labels[i]
    predicted_label = np.argmax(predictions_array)
    if predicted_label != true_label:
        fall_list.append(predicted_label)
        fall_label.append(true_label)
        fall_image.append(img[i])
        fall_arglist.append(predictions_array)

for i in range(len(test_images)):
    append_falllist(i, predictions[i], test_labels, test_images)

num_rows = 5
num_cols = 3
num_images = num_rows * num_cols
plt.figure(figsize=(2 * 2 * num_rows, 2 * num_cols))
for i in range(min(num_images, len(fall_image))):
    plt.subplot(num_rows, 2 * num_cols, 2 * i + 1)
    plt.grid(False)
    plt.xticks([])
    plt.yticks([])
    plt.imshow(fall_image[i].reshape(28, 28), cmap=plt.cm.binary)
    plt.xlabel("{} {:2.0f}% ({})".format(class_names[fall_list[i]], 100 * np.max(fall_arglist[i]), class_names[fall_label[i]]), color="red")
    plt.subplot(num_rows, 2 * num_cols, 2 * i + 2)
    plt.grid(False)
    plt.xticks(range(10))
    plt.yticks([])
    thisplot = plt.bar(range(10), fall_arglist[i], color="#777777")
    plt.ylim([0, 1])
    thisplot[fall_list[i]].set_color('red')
    thisplot[fall_label[i]].set_color('blue')
plt.tight_layout()
plt.show()